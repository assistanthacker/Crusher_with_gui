email = "<your_email>"
email_password = "<your_email_password>"
wolframalpha_id = "44EPEQ-LUTH78WKXL"
